# tenby_password

## Instructions

1. Clone the repository.
2. Navigate to the local repository and navigate to the relevant station (station1 or station4).
3. Open wordle.html.
4. The code should then run in the browser.